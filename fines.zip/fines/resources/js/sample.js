/**
 * Controller JavaScript to manage the functions of the page. The init function
 * is located near the bottom, which will bind actions to all buttons.
 */

var _finesse,workCallid,consultCallid,agentOldState,agentState,workCallidOldState,workCallidState,consultCallidOldState,consultCallidState,consultFlag,participantsNum,
consultFromFlag,
//Store agent information
_username, _password, _extension, _domain, _login,

//Private reference to JabberWerx eventing object.
_jwClient;


//依次为：小键盘、登入、登出、就绪、ACW、外呼、应答、挂机、保持、恢复、转移磋商、会议磋商、转移、会议、取回、单步转移
var status_codes = [
	['_init',0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	['_login',1,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0],
	['_ready',0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0],
	['_ringing',0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0],
	['_connected',1,0,0,0,0,0,0,1,1,0,1,1,0,0,0,0],
	['_hold',0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
	['_unhold',1,0,0,0,0,0,0,1,1,0,1,1,0,0,0,0],
	['_hangup',1,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0],
	['_acw',0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0],
	['_notReady',1,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0],
	['_logout',0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	['_consult',0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0],
	['_afterConsultconnected',1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
	['_consultconnected',0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0]
];

function _postParentMessage(data) {
	if(top != self){ //说明是在框架中使用
		console.log(data);
		var nodestr = JSON.stringify(data);
		parent.postMessage(nodestr, "*");
	}
}
/**
 * Reset the sample page back to a signed out state.
 */
function _reset() {
	//Clear console.
	// $("#console-area").val("");

	//Show sign in boxes.
	// $("#div-signin").show();

	//Hide all API actions DIV until successful sign in.
	//$("#actions").hide();

	//Hide agent info DIV until successful sign in.
	//$("#div-signout").hide();

	//Reset agent info data.
	//$("#span-agent-info").html("");

	//Clear the dial number field.
	//$("#field-call-control-make-dialnum").val("");

	//Clear the callid field.
	//$("#field-call-control-callid").val("");
}

function replaceAll(str, stringToReplace, replaceWith) {
	var result = str, index = 1;
	while (index > 0) {
		result = result.replace(stringToReplace, replaceWith);
		index = result.indexOf(stringToReplace);
	}
 	return result;
}

/**
 * Print text to console output.
 */
function print2Console(type, data) {
	var date = new Date(),
	xml = null;
	consoleArea = $("#console-area");
	if (type === "EVENT") {
		xml = data.data._DOM.xml;
		xml = replaceAll(xml, "&lt;", "<");
		xml = replaceAll(xml, "&gt;", ">");
		consoleArea.val(consoleArea.val() + "[" + date.getTime() + "] [" + type + "] " + xml + "\n\n");
	} else  {
		//Convert data object to string and print to console.
		consoleArea.val(consoleArea.val() + "[" + date.getTime() + "] [" + type + "] " + data + "\n\n");
	}
	//Scroll to bottom to see latest.
	consoleArea.scrollTop(consoleArea[0].scrollHeight);
	consoleArea = null;
}

function onClientError(rsp) {
	//print2Console("ERROR " + rsp);
}

/**
 * Event handler that prints events to console.
 */
function _eventHandler(data) {
	////print2Console("EVENT", data);
	data = data.selected.firstChild.data;
	//////print2Console("MYEVENT", data);
	// try to get the callid

	var dialogs = $(data).find("dialogs").text();
	//console.log("dialogs="+dialogs);
	//console.log(dialogs.indexOf("finesse/api/User",0));
	if (dialogs.indexOf("finesse/api/User", 0) > 0) {
		var state = $(data).find("state");
		var label = $(data).find("label");
		//console.log("state"+state.text()+",agentState="+agentState);
		//agentOldState,agentState,workCallidOldState,workCallidState,consultCallidOldState,consultCallidState,
		if (state.text() != agentState) {
			agentOldState = agentState;
			agentState = state.text();
			//$("#field-call-control-agent-state").val(agentState);
			var stateName = "";
			if (state.text() == 'LOGIN') {
				stateName = "登录";
			} else if (state.text() == 'LOGOUT') {
				stateName = "登出";
			} else if (state.text() == 'NOT_READY') {
				stateName = "置忙";
			} else if (state.text() == 'WORK') {
				stateName = "话后";
			} else if (state.text() == 'READY') {
				stateName = "就绪";
			} else if (state.text() == 'HOLD') {
				stateName = "保持";
			} else if (state.text() == 'RESERVED') {
				stateName = "预占";
			} else if (state.text() == 'RESERVED-OUTBOUND') {
				stateName = "外呼预占";
			} else if (state.text() == 'WORK_READY') {
				stateName = "话后就绪";
			} else if (state.text() == 'TALKING') {
				stateName = "通话";
			} else {
				stateName = "未知";
			}
			if (label.text() !== '') {
				$('#agent_state').html("坐席状态：" + stateName + "-" + label.text());
			} else {
				$('#agent_state').html("坐席状态：" + stateName);
			}

			$("#field-call-control-agent-old-state").val(agentOldState);
			//console.log("222 consultCallid="+consultCallid);
			//console.log("consultFlag="+consultFlag+",participantsNum="+participantsNum+",agentOldState="+agentOldState+",agentState="+agentState);
			if ((consultFlag == "1" || participantsNum > 2) && (agentOldState == "HOLD" || agentState == "HOLD")) {
				if (state.text() == 'TALKING') {
					setBottonDisplay('_afterConsultconnected');
				}
				//console.log("绾惧鏅㈤幋鏍拷娴兼俺顔呯�鑹板毀娣囨繃瀵旈崣妯哄閿涘苯鎷烽悾锟�;
				//////print2Console("LOG","蹇界暐");
			} else {
				//console.log("鐎涙ê婀崸鎰厬閻樿埖锟介崣妯哄");"
				//////print2Console("LOG","宸插彉鍖�);
				if (state.text() == 'READY') {
					setBottonDisplay('_ready');
				} else if (state.text() == 'NOT_READY') {
					setBottonDisplay('_notReady');
				} else if (state.text() == 'TALKING') {
					timeinsec = 0;
					setBottonDisplay('_connected');
				} else if (state.text() == 'HOLD') {
					setBottonDisplay('_hold');
				}
			}
			//////print2Console("AGENTSTATE", "workCallid="+workCallid+",consultCallid="+consultCallid+",agentOldState="+agentOldState+",agentState="+agentState+",consultFlag="+consultFlag+",participantsNum="+participantsNum);
		}
	} else {
		var callid = $(data).find("id");
		var fromAddress = $(data).find("fromAddress");
		if (callid.text() !== "") {
			$("#field-call-control-callid").val(callid.text());
		}
		var callvariablesData = $(data).find("callvariables").children();
		var uui = callvariablesData.eq(0).find("value").text();
		var participantsData = $(data).find("participants").children();
		participantsNum = participantsData.length;
		for (var i = 0; i < participantsData.length; i++) {
			var participantsAddress = participantsData.eq(i).find("mediaAddress").text();
			var participantsState = participantsData.eq(i).find("state").text();
			// alert("participantsAddress="+participantsAddress+",_extension="+_extension+",participantsState="+participantsState)
			//console.log("participantsAddress="+participantsAddress+",_extension="+_extension+",participantsState="+participantsState);
			if (participantsAddress == _extension) {
				if ((workCallid == null || workCallid == '' || workCallid == callid.text()) && consultCallid != callid.text()) {
					workCallid = callid.text();
					//$("#field-call-control-callid1").val(callid.text());
					if (workCallidState == null || participantsState != workCallidState) {
						workCallidOldState = workCallidState;
						workCallidState = participantsState;
						//$("#field-call-control-callid1-old-state").val(workCallidOldState);
						//$("#field-call-control-callid1-state").val(participantsState);
						//console.log("participantsState="+participantsState+",workCallid="+workCallid+",consultCallid="+consultCallid+",consultFromFlag="+consultFromFlag);
						if (participantsState == 'ALERTING') {
							timeinsec = 0;
							setBottonDisplay('_ringing');
							console.log('ALERTING');
						} else if (participantsState == 'WRAP_UP') {
							timeinsec = 0;
							setBottonDisplay('_hangup');
							console.log('WRAP_UP');
						} else if (participantsState == 'ACTIVE' && consultFromFlag == '1') {
							setBottonDisplay('_afterConsultconnected');
							console.log('ACTIVE');
						} else if (participantsState == 'ACTIVE') {
							setBottonDisplay('_connected');
							console.log('已接听');
							// _postParentMessage({ // ================================== 电话
							// 	callId: workCallid,
							// 	toAddress: participantsData.eq(i + 1).find("mediaAddress").text()
							// })
						} else if (participantsState == 'DROPPED' && consultCallid == null) {
							consultFromFlag = "0";
							timeinsec = 0;
							setBottonDisplay('_hangup');
							console.log('DROPPED');
							_postParentMessage({ // ================================== // 外呼电话已挂断
								callId: callid.text(),
								dropCall: $(data).find('dialednumber').text(),
							})
						}

						//console.log("鐎涙ê婀柅姘崇樈閻樿埖锟介崣妯哄");
						//////print2Console("LOG","鐎涙ê婀柅姘崇樈閻樿埖锟介崣妯哄");
						////print2Console("participant STATE", "workCallid="+workCallid+",consultCallid="+consultCallid+",agentOldState="+agentOldState+",agentState="+agentState+",workCallidOldState="+workCallidOldState+",workCallidState="+workCallidState+",consultFlag="+consultFlag+",participantsNum="+participantsNum);
					}

					if (participantsState == 'DROPPED') {
						//$("#field-call-control-callid1").val("");
						//$("#field-call-control-callid1-old-state").val("");
						//$("#field-call-control-callid1-state").val("");
						workCallid = null;
						workCallidState = null;
						workCallidOldState = null;
						consultFlag = null;
						participantsNum = null;
						console.log('DROPPED');
					} else if (participantsState == 'ALERTING') { // 来电才会触发
						$('#dial_text').html(fromAddress.text());
						_postParentMessage({ // ================================== 电话
							phone: fromAddress.text(),
							callId: workCallid,
							fromAddress: fromAddress.text(),
							ivrV: uui
						})
						console.log("主叫：" + fromAddress.text() + " ;被叫：" + participantsAddress + " ;callid=" + callid.text() + " ;uui=" + uui);
					}
				} else {
					if (consultCallid == null || consultCallid == '') {
						consultCallid = callid.text();
					}
					// console.log("consultCallid="+consultCallid);
					// $("#field-call-control-callid2").val(callid.text());	
					if (participantsState != consultCallidState) {
						//console.log("1111participantsState="+participantsState+",workCallid="+workCallid+",consultCallid="+consultCallid+",consultFromFlag="+consultFromFlag);
						if (participantsState == 'ACTIVE' && consultFromFlag == "1") {
							setBottonDisplay('_consultconnected');
							console.log('ACTIVE consultFromFlag == "1"');
						} else if (participantsState == 'ACTIVE' && consultFromFlag != "1") {
							setBottonDisplay('_afterConsultconnected');
							console.log('ACTIVE consultFromFlag != "1"');
						} else if (participantsState == 'INITIATING') {
							consultFromFlag = "1";
							setBottonDisplay('_consult');
							console.log('INITIATING');
						} else if (participantsState == 'DROPPED') {
							consultFromFlag = "0";
							timeinsec = 0;
							setBottonDisplay('_hangup');
							console.log('DROPPED participantsState != consultCallidState');
						}
						consultCallidOldState = consultCallidState;
						consultCallidState = participantsState;
						//$("#field-call-control-callid2-old-state").val(consultCallidOldState);
						//$("#field-call-control-callid2-state").val(participantsState);
						//console.log("鐎涙ê婀壕瀣櫌闁俺鐦介悩鑸碉拷閸欐ê瀵�);
						//////print2Console("LOG","鐎涙ê婀壕瀣櫌闁俺鐦介悩鑸碉拷閸欐ê瀵�);
						//////print2Console("participant STATE", "workCallid="+workCallid+",consultCallid="+consultCallid+",agentOldState="+agentOldState+",agentState="+agentState+",consultCallidOldState="+consultCallidOldState+",consultCallidState="+consultCallidState+",consultFlag="+consultFlag+",participantsNum="+participantsNum);
					}
					if (participantsState == 'DROPPED') {
						//$("#field-call-control-callid2").val("");
						//$("#field-call-control-callid2-old-state").val("");
						//$("#field-call-control-callid2-state").val("");
						consultCallid = null;
						consultCallidState = null;
						consultCallidOldState = null;
						consultFlag = "0";
						console.log('DROPPED');
					}
				}
			} else {
				if (participantsState === 'ACTIVE') {
					console.log('外呼电话');
					_postParentMessage({ // ================================== 电话
						phone: participantsAddress,
						callId: callid.text(),
						toAddress: participantsAddress
					})
				}
				if (participantsState === 'DROPPED' && _extension == fromAddress.text() && _extension != participantsAddress) {
					console.log('外呼电话已挂断（接听过）');
					_postParentMessage({ // ================================== // 外呼电话已挂断
						callId: callid.text(),
						dropCall: participantsAddress,
						isHangUp: true
					})
				}
				console.log("主叫：" + fromAddress.text() + " ;被叫：" + participantsAddress + " ;callid=" + callid.text() + " ;uui=" + uui, participantsState);
			}
		}
	}

	//agentOldState,agentState,workCallidOldState,workCallidState,consultCallidOldState,consultCallidState,
	//////print2Console("STATE", "agentOldState="+agentOldState+",agentState="+agentState+",workCallidOldState="+workCallidOldState+",workCallidState="+workCallidState+",consultCallidOldState="+consultCallidOldState+",consultCallidState="+consultCallidState);

	var source = $(data).find("source");
	//console.log("source"+source.text());
	var state = $(data).find("state");
	//console.log("state"+state.text());
	callid = null;

}

/**
 * Connects to the BOSH connection. Any XMPP library or implementation can be
 * used to connect, as long as it conforms to BOSH over XMPP specifications. In
 * this case, we are using Cisco's Ajax XMPP library (aka JabberWerx). In order
 * to make a cross-domain request to the XMPP server, a proxy should be
 * configured to forward requests to the correct server.
 */
function _eventConnect() {
	if (window.jabberwerx) {
		var
			//Construct JID with username and domain.
			jid = _username + "@" + _domain,
			//Create JabbwerWerx object.
			_jwClient = new jabberwerx.Client("cisco");
		//Arguments to feed into the JabberWerx client on creation.
		jwArgs = {
			//Defines the BOSH path. Should match the path pattern in the proxy
			//so that it knows where to forward the BOSH request to.
			httpBindingURL: "/fines/http-bind",
			//Calls this function callback on successful BOSH connection by the
			//JabberWerx library.
			errorCallback: onClientError,
			successCallback: function () {
				//Get the server generated resource ID to be used for subscriptions.
				_finesse.setResource(_jwClient.resourceName);
			}
		};
		jabberwerx._config.unsecureAllowed = true;
		//Bind invoker function to any events that is received. Only invoke
		//handler if XMPP message is in the specified structure.
		_jwClient.event("messageReceived").bindWhen("event[xmlns='http://jabber.org/protocol/pubsub#event'] items item notification", _eventHandler);
		_jwClient.event("clientStatusChanged").bind(function (evt) {
			if (evt.data.next == jabberwerx.Client.status_connected) {
				// attempt to login the agent
				_finesse.signIn(_username, _extension, true, _signInHandler, _signInHandler);
			} else if (evt.data.next == jabberwerx.Client.status_disconnected) {
				_finesse.signOut(_username, _extension, null, _signOutHandler, _signOutHandler);
			}
		});
		//Connect to BOSH connection.
		_jwClient.connect(jid, _password, jwArgs);
	} else {
		console.log("CAXL library not found. Please download from http://developer.cisco.com/web/xmpp/resources")
	}
}

/**
 * Disconnects from the BOSH connection.
 */
function _eventDisconnect() {
	if (_jwClient) {
		_jwClient.disconnect();
		_jwClient = null;
	}
}

/**
 * Generic handler that prints response to console.
 */
function _handler(data, statusText, xhr) {
    if(xhr) {
        //print2Console("RESPONSE", xhr.status);
    } else {
			//print2Console("RESPONSE", data);
    }
}

/**
 * GetState handler that prints response to console.
 */
function _getStateHandler(data) {
   // ////print2Console("RESPONSE", data.xml);
}

/**
 * Handler for the make call that will validate the response and automatically
 * store the call id retrieve from the response data.
 */
function _makeCallHandler(data, statusText, xhr) {
  	// print2Console("Make call RESPONSE", statusText);
    // Validate success.
    if (statusText === "success") {
        $("#field-call-control-callid").val("");
    }
}

/**
 * 
 * Sign in handler. If successful, hide sign in forms, display actions, and
 * connect to BOSH channel to receive events
 * 
 */
function _signInHandler(data, statusText, xhr) {
	if (xhr.status === 202) {
		startTimer();
		// Hide signin forms and show actions.
		$("#div-signin").hide();
		$("#actions").show();
		$("#div-signout").show();
		$("#span-agent-info").html("Logged in as <b>" + _username + "</b> with extension <b>" + _extension + "</b>");
		setBottonDisplay('_login');
	}
}

function _signOutHandler(data, statusText, xhr) {
	//print2Console("Sign out RESPONSE", xhr.status)
	//Ensure success
	_postParentMessage({ // ================================== 菜单
		phone: '',
		notReadyMenu: false,
		logoutMenu: false,
		phoneMenu: false
	})
	if (xhr.status === 202) {
		// Disconnect from getting events
		_eventDisconnect();

		// Clean up the values of objects
		_reset();
		_username = null;
		_password = null;
		_extension = null;
		_domain = null;

		// Clean up the Finesse object
		_finesse = null;
		// Reload the page after successful sign out.
		// go to logout.jsp
		_postParentMessage({ // ================================== 菜单
			logout: true
		})
		// window.location.reload();
	}
}

/**
 * Init function. Wait until document is ready before binding actions to buttons
 * on the page.
 */
$(document).ready(function () {
	window.addEventListener('message', function(event) {
		console.log('电话系统：', event);
		if (typeof(event.data) != 'string') {
			return false;
		}
		try {
			var data = JSON.parse(event.data)
			if (!!data.agentid && !!data.extension) { // 初始化员工编号，座机电话
				$("#field-agentid").val(data.agentid);
				$("#field-extension").val(data.extension);
				$("#field-password").val(data.password || '123456');
				$("#field-domain").val(data.domain || '1');
				login_finesse()
			}
			if (!!data.event) { // 事件触发
				if (data.event === 'phoneMenuEvent') { // 电话面板事件
					var eventValue = data.value;
					if (eventValue == 'c') { // 清除
						$('#phoneno').val('');
					} else if (eventValue == 'd') { // 点击拨号盘中的拨打按钮时的事件函数
						if (!!data.phone) {
							makecall(data.phone);
						} else {
							makecall()
						}
						return false
					} else if (eventValue == 'b') { // 回删
						$('#phoneno').val(function() {
							if (this.value.length) {
								return this.value.substring(0, this.value.length - 1);
							}
							return '';
						});
					} else if (!!eventValue && !isNaN(eventValue)) {
						$('#phoneno').val(function() {
							return this.value + '' + eventValue;
						});
						$('#dial_text').html($('#phoneno').val());
					}
					_postParentMessage({ // ================================== 电话
						phone: $('#phoneno').val()
					})
				} else if (data.event === 'logoutEvent') { // 登出事件（签出，午餐）
					_id_logout1Fn()
				} else if (data.event === 'notReadyEvent') {
					if (data.hasOwnProperty('value') && !isNaN(data.value)) {
						not_ready(Number(data.value))
					}
				}

			}
		} catch (error) {
			console.log(error);
		}
	});

	_reset();
	setBottonDisplay('_init');

	//Binds the button to clear the console output box.
	$("#button-clear-console").click(function () {
		$("#console-area").val("");
	});

	/** Bind all buttons to actions **/
	// SYSINFO button
	$("#form-sysinfo").submit(function() {
	  _finesse.sysInfo(_handler, _handler);
	});

	function login_finesse() {
		//Grabs the credentials from the input fields.
		_username = $("#field-agentid").val();
		_password = $("#field-password").val();
		_extension = $("#field-extension").val();
		_domain = $("#field-domain").val();
		consultFromFlag="0";
		//Check non-empty fields
		if (!_username || !_password || !_extension || !_domain) {
			console.log("Please enter valid domain and credentials.");
		} else {
			login = true;
			//Create Finesse object and sign in user. On successful sign in, a
			//handler will be invoked to present more API options in UI.
			_finesse = new Finesse(_username, _password);
			_eventConnect();
		}
		return false;
	}
	//SIGNOUT button
	$("#id_login").click(login_finesse);
    
    //SIGNOUT button
    //CHANGE AGENT STATE READY button
    $("#id_ready").click(function () {
    	timeinsec=0;
			var newState = "READY"
			if (newState) {
				_finesse.changeState(_username, newState, null, _handler, _handler);
			}
			$('#phoneno').val('')
			$('#dial_text').text('')
			_postParentMessage({ // ================================== 来电
				phone: $('#phoneno').val()
			})
    });
  
    //ANSWER CALL button
    $("#id_makecall").click(function () {
    	var phoneConsult = $("#phoneno").val();
    	if(phoneConsult == ''){
    		console.log('请输入电话号码！');
				$('#phone_dial').show();
				_postParentMessage({ // ================================== 电话面板菜单
					phoneMenu: true
				})
				return false;
    	}
			makecall();
    });
    
    //ANSWER CALL button
    $("#id_answer").click(function () {
    	timeinsec = 0;
			var callId = $("#field-call-control-callid").val();
			_finesse.answerCall(callId, _extension, _handler, _handler);
			// _postParentMessage({ // ================================== 来电
			// 	callId: callId,
			// 	fromAddress: $('#dial_text').text()
			// })
    });

    //HOLD CALL button
    $("#id_hold").click(function () {
    	timeinsec=0;
			var callId = $("#field-call-control-callid").val();
			_finesse.holdCall(callId, _extension, _handler, _handler);
    });
    
  	//UNHOLD CALL button
    $("#id_unhold").click(function () {
			var callId = $("#field-call-control-callid").val();
			_finesse.retrieveCall(callId, _extension, _handler, _handler);
    });
  
    $("#id_transferConsult").click(function () {
    	var phoneConsult = $("#phoneno").val();
    	if(phoneConsult==''){
    		console.log('请输入磋商电话！');
				$('#phone_dial').show();
				_postParentMessage({ // ================================== 电话面板菜单
					phoneMenu: true
				})
				return false;
    	}
		consultFlag="1";
			var callId = $("#field-call-control-callid").val();
			//workCallid = callId;
			_finesse.consultCall(callId, _extension, phoneConsult, _handler, _handler);
    });
    
    $("#id_conferenceConsult").click(function () {
    	var phoneConsult = $("#phoneno").val();
    	if(phoneConsult==''){
    		console.log('请输入磋商电话！');
				$('#phone_dial').show();
				_postParentMessage({ // ================================== 电话面板菜单
					phoneMenu: true
				})
				return false;
    	}
			consultFlag ="1";
			var callId = $("#field-call-control-callid").val();
			//workCallid = callId;
			_finesse.consultCall(callId, _extension, phoneConsult, _handler, _handler);
    });
    
	//transfer CALL button
    $("#id_transfer").click(function () {
			consultFlag ="0";
			var callId = $("#field-call-control-callid").val();
			_finesse.transferCall(callId, _extension, _handler, _handler);
    });

	 //conference CALL button
    $("#id_conference").click(function () {
		consultFlag ="0";
		var callId = $("#field-call-control-callid").val();
        _finesse.conferenceCall(callId, _extension, _handler, _handler);
    });
    
    $("#id_retrieve").click(function () {
		consultFlag ="0";
        //var callId = $("#field-call-control-callid").val();
		//consultCallid = callId;
		 _finesse.dropCall(consultCallid, _extension, _handler, _handler);
		 window.setTimeout("_finesse.retrieveCall(workCallid, _extension, _handler, _handler)", 500); 
    });
    
    $("#id_ss_trans").click(function () {
    	var phoneConsult = $("#phoneno").val();
    	if(phoneConsult==''){
    		// console.log('请输入磋商电话！');
				$('#phone_dial').show();
				_postParentMessage({ // ================================== 电话面板菜单
					phoneMenu: true
				})
				return false;
    	}
			var callId = $("#field-call-control-callid").val();
			_finesse.singleTransferCall(callId, _extension, phoneConsult, _handler, _handler);
    });

     //DROP CALL button
	$("#id_hangup").click(function () {
		timeinsec=0;
			var callId = $("#field-call-control-callid").val();
			_finesse.dropCall(callId, _extension, _handler, _handler);
	});
	function _id_dialmenuFn() {
		$('#submenu_busy').hide();
		$('#submenu_logout').hide();
		if ($('#phone_dial:visible').length) {
			$('#phone_dial').hide();
			_postParentMessage({ // ================================== 电话面板菜单
				phoneMenu: false,
				notReadyMenu: false
			})
		} else {
			$('#phone_dial').show();
			_postParentMessage({ // ================================== 电话面板菜单
				phoneMenu: true,
				notReadyMenu: false
			})
		}
	}
	$('#id_dialmenu').click(_id_dialmenuFn);
	//拨号面板各数字按键事件
	$('#phone_dial span').click(function() {
		var v = $(this).attr('value');
		if (v == 'c') { // 清除
			$('#phoneno').val('');
		} else if (v == 'd') {//点击拨号盘中的拨打按钮时的事件函数
			makecall();
		} else if (v == 'b') { // 回删
			$('#phoneno').val(function() {
				if (this.value.length) {
					return this.value.substring(0, this.value.length - 1);
				}
				return '';
			});
		} else {
			$('#phoneno').val(function() {
				return this.value + '' + v;
			});
		}
		$('#dial_text').html($('#phoneno').val());
		_postParentMessage({ // ================================== 电话
			phone: $('#phoneno').val()
		})
	});
	
	$('#id_notready100').click(function(e) {
		$('#phone_dial').hide();
		$('#submenu_logout').hide();
		// $("#submenu_busy").css("left",e.pageX);
		// showsubmenu('busy');
		_postParentMessage({ // ================================== 置忙菜单
			notReadyMenu: true,
			phoneMenu: false,
		})
	});
	$('#id_logout').click(function(e) {
		// _id_logout1Fn(e)
		$('#phone_dial').hide();
		$('#submenu_busy').hide();
		// $("#submenu_logout").css("left", e.pageX);
		// showsubmenu('logout');
		_postParentMessage({ // ================================== 菜单
			notReadyMenu: false,
			logoutMenu: true,
			phoneMenu: false,
			logoutConfirm: true
		})
	});
	
	function _id_logout1Fn(e) {
		not_ready(2);
		window.setTimeout(function() {
			_finesse.signOut(_username, _extension, null, _signOutHandler, _signOutHandler)
		}, 500);
	}
	$('#id_logout1').click(_id_logout1Fn);
	function _id_logout2Fn(e) {
		not_ready(2);
		window.setTimeout("_finesse.signOut(_username, _extension, null, _signOutHandler, _signOutHandler)", 500);
	}
	$('#id_logout2').click(_id_logout2Fn);
});

function showsubmenu(sid) {
	var whichEl;
	whichEl = eval("submenu_" + sid);
	if (whichEl.style.display == "none"){
		eval("submenu_" + sid + ".style.display=\"\";");
	}
	else{
		eval("submenu_" + sid + ".style.display=\"none\";");
	}
}

function not_ready(type) {
	$('#submenu_busy').hide();
	_postParentMessage({ // ================================== 置忙菜单
		notReadyMenu: false
	})
	timeinsec=0;
	var newState = "NOT_READY";
	if (newState) {
		_finesse.changeState(_username, newState, type || null, _handler, _handler);
	}
	var reason="";
	switch (type) {
		case 1:
			reason = "小休";
		break;
		case 2:
			reason = "系统问题";
		break;
		case 3:
			reason = "会议";
		break;
		case 4:
			reason = "培训";
		break;
		case 5:
			reason = "资深员工工作";
		break;
		case 6:
			reason = "辅导";
		break;
		case 7:
			reason = "话后工作 (OB)";
		break;
		case 8:
			reason = "Back Office";
		break;
		case 9:
			reason = "外呼";
		break;
		case 10:
			reason = "话后工作 (IB)";
		break;
		default:
				reason="未定义";
			break;
	}
	$('#agent_state').html("坐席状态：" + !!type ? '置忙-' : '' + reason);
}

function makecall(phone) {
	if (!!phone) {
		$("#phoneno").val(phone)
	}
	var dialNum = $("#phoneno").val();
	if(dialNum === ''){
		// console.log('请输入拨打号码！');
		$('#phone_dial').show();
		$('#dial_text').html($('#phoneno').val());
		_postParentMessage({ // ================================== 电话
			phoneMenu: true
		})
		return false;
	}
	_postParentMessage({ // ================================== 电话
		phone: $('#phoneno').val()
	})
	_finesse.makeCall(dialNum, _extension, _makeCallHandler, _handler);
	return false;
}

function setBottonDisplay(status){
	agentStatus=status;
	for(var i=0;i<status_codes.length;i++){
		if(status==status_codes[i][0]){
			//小键盘
			if(status_codes[i][1]==0){
				$("#sp_dialmenu").css("display","none");
			}else{
				$("#sp_dialmenu").css("display","");
			}
			//登录
			if(status_codes[i][2]==0){
				$("#sp_id_login").css("display","none");
			}else{
				// $("#sp_id_login").css("display","");
			}
			//登出
			if(status_codes[i][3]==0){
				$("#sp_id_logout").css("display","none");
			}else{
				$("#sp_id_logout").css("display","");
			}
			//就绪
			if(status_codes[i][4]==0){
				$("#sp_id_ready").css("display","none");
			}else{
				$("#sp_id_ready").css("display","");
			}
			//ACW
			if(status_codes[i][5]==0){
				$("#sp_id_notready100").css("display","none");
			}else{
				$("#sp_id_notready100").css("display","");
			}
			//外呼
			if(status_codes[i][6]==0){
				$("#sp_id_makecall").css("display","none");
			}else{
				$("#sp_id_makecall").css("display","");
			}
			//应答
			if(status_codes[i][7]==0){
				$("#sp_id_answer").css("display","none");
			}else{
				$("#sp_id_answer").css("display","");
			}
			//挂机
			if(status_codes[i][8]==0){
				$("#sp_id_hangup").css("display","none");
			}else{
				$("#sp_id_hangup").css("display","");
			}
			//保持
			if(status_codes[i][9]==0){
				$("#sp_id_hold").css("display","none");
			}else{
				$("#sp_id_hold").css("display","");
			}
			//恢复
			if(status_codes[i][10]==0){
				$("#sp_id_unhold").css("display","none");
			}else{
				$("#sp_id_unhold").css("display","");
			}
			//转移磋商
			if(status_codes[i][11]==0){
				$("#sp_id_transferConsult").css("display","none");
			}else{
				$("#sp_id_transferConsult").css("display","");
			}
			//会议磋商
			if(status_codes[i][12]==0){
				$("#sp_id_conferenceConsult").css("display","none");
			}else{
				$("#sp_id_conferenceConsult").css("display","");
			}
			//转移
			if(status_codes[i][13]==0){
				$("#sp_id_transfer").css("display","none");
			}else{
				$("#sp_id_transfer").css("display","");
			}
			//会议
			if(status_codes[i][14]==0){
				$("#sp_id_conference").css("display","none");
			}else{
				$("#sp_id_conference").css("display","");
			}
			//取回
			if(status_codes[i][15]==0){
			 	$("#sp_id_retrieve").css("display","none");
			}else{
			 	$("#sp_id_retrieve").css("display","");
			}
			//单步转移
			if(status_codes[i][16]==0){
				$("#sp_id_ss_trans").css("display","none");
			}else{
				$("#sp_id_ss_trans").css("display","");
			}
		}
	}
}

function formatMinutes(minutes){
    var day = parseInt(Math.floor(minutes / 1440));
    var hour = day >0
        ?Math.floor((minutes - day*1440)/60)
        :Math.floor(minutes/60);
    var minute = hour > 0
        ? Math.floor(minutes -day*1440 - hour*60)
        :minutes;
    var time="";
    if (day > 0) time += day + ":";
    time += (hour > 9?hour:'0'+hour) + ":";
    //if (hour > 0) time += hour + "小时";
    //if (minute > 0) time += minute + "分钟";
    time += (minute > 9?minute:'0'+minute) + ":";
    return time;
}

//格式化秒数为时分秒
function formatSeconds(seconds) {
	if(seconds >0){
		var minutes = Math.floor(seconds/60);
		seconds = seconds - minutes * 60;
		return formatMinutes(minutes) + (seconds < 10  ?  "0"+seconds  : seconds);
	}
	return seconds;
}

var timeinsec=0;
var timerFlag=false;
function startTimer(){
	if (!timerFlag) {
		timeinsec=0;
		this.interval = setInterval(function() {
			timeinsec++;
			$('#sp_timer').html(formatSeconds(timeinsec));
		}, 1000);
		timerFlag = true;
	}
}
function stopTimer(){
	$('body').stopTime('A');
	timeinsec=0;
	$('#sp_timer').html('');
	timerFlag = false;
}
